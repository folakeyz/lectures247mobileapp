export const BASE_URL = "https://api.lectures247.com";
